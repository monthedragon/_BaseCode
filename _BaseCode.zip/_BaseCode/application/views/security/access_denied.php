<a href='<?=base_url()?>security/logout'>logout</a>
<center><h2>ACCESS DENIED</h2></center>