<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?> </title>
	<link rel='stylesheet'   type="text/css"  href='<?=base_url()?>assets/css/default_login.css'> 
	<link rel='stylesheet'   type="text/css"  href='<?=base_url()?>assets/css/jquery-ui.css'> 
	<link rel='stylesheet'   type="text/css"  href='<?=base_url()?>assets/css/basic.css'> 
	
	
	<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.1.9.1.js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/js/jquery-ui.js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/js/jquery-validate.js"></script>
	
	
</head>

<body> 

<table width="100%" height="100%" align="center" bgcolor="#FFFFFF">
<tr>
<td  align="center" valign='top'>
 
<div class="content">
    <div class='div-logo'>
        <img src='../assets/images/logo.PNG' width=300px >
   </div>
 

 