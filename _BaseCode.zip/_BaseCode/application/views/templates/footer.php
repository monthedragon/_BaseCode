<div id='div-manage'></div>
<div id='div-loader'>Please wait..</div>
</div>
</td>
</tr>
<tr>
<td class="pagefooter">
Powered by CI &copy;2013<br>
</td>
</tr>
</table>
</body> 
</html>
