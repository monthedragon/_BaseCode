<?foreach($attachments as $att){?>
	<?='<a href=#>'.$att['filename'].'</a> ; '?>  
<?}?>
