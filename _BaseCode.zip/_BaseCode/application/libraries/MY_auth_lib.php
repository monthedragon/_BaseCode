<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class my_auth_lib extends CI_Loader {
	function callMeNow2(){
		return "Hello world!";
	}
}

/* End of file MY_Auth_lib.php */
/* Location: ./application/libraries/MY_Auth_lib.php */ 
?>