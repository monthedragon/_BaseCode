<?php


/* End of file upload_lang.php */
/* Location: ./system/language/english/upload_lang.php */